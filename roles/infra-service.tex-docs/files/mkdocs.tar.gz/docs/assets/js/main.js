// magnific popup
$('.video-link').magnificPopup({
  type: 'iframe'  
});